package com.jack.cardviewdemo;

import android.widget.BaseAdapter;

public abstract class BaseCardAdapter extends BaseAdapter {

}
